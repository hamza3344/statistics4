﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace statistics4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String[] values = textBox1.Text.Split(",");
            List<double> doublevalue = new List<double>();
            foreach(String s in values)
            {
                doublevalue.Add(double.Parse(s));
            }
            doublevalue.Sort();
            double q1 = 0;
            double q2 = median(doublevalue);
            double q3 = 0;
            int halflenght = doublevalue.Count / 2;
            if(doublevalue.Count%2==0)
            {
                q1 = median(doublevalue.GetRange(0, halflenght));
                q3 = median(doublevalue.GetRange(halflenght, halflenght));
            }
            else
            {
                q1 = median(doublevalue.GetRange(0, halflenght));
                q3 = median(doublevalue.GetRange(halflenght+1, halflenght));
            }
            double interq = q3 - q1;
            MessageBox.Show("Q1 " + q1);
            MessageBox.Show("Q2 " + q2);
            MessageBox.Show("Q3 " + q3);
            MessageBox.Show("Interquartile " + interq);

        }
        public double median(List<double> median)
        {
            if(median.Count%2==0)
            {
                return (median[median.Count / 2] + median[median.Count / 2 - 1]) / 2;
            }
            else
            {
                return median[median.Count / 2];
            }
        }
    }
}
